/* This file is Auto-Generated Using CheckMate.
 Please Do Not Directly Modify.
 */ 

#define EOF (-1)
