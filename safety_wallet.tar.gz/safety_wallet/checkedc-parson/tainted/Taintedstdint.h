/* This file is Auto-Generated Using CheckMate.
 Please Do Not Directly Modify.
 */ 

#  define SIZE_MAX		(18446744073709551615UL)
