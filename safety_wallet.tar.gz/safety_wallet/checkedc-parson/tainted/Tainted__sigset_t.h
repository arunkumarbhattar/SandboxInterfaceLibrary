/* This file is Auto-Generated Using CheckMate.
 Please Do Not Directly Modify.
 */ 

#define _SIGSET_NWORDS (1024 / (8 * sizeof (unsigned long int)))
