/* This file is Auto-Generated Using CheckMate.
 Please Do Not Directly Modify.
 */ 

#define __NFDBITS	(8 * (int) sizeof (__fd_mask))
